main() {
typedef int FILE;
int B;
FILE a;}