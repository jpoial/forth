main()
{  /* wlozhennye /* kommentarii */ */
  int _$;
  int const * A;
  interrupt void f();
  "razrechaetsja" "neskolko" "stringow" "podrjad" ;
};
